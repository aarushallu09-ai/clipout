import assert from "node:assert/strict";
import test from "node:test";
import { validateAnalysis } from "./analyzer.mjs";

function validReport() {
  return {
    videoStatus: "available",
    durationSeconds: 210,
    error: "",
    moments: Array.from({ length: 6 }, (_, index) => ({
      startSeconds: index * 30,
      endSeconds: index * 30 + 24,
      title: `Moment ${index + 1}`,
      reason: "A short source-grounded explanation.",
    })),
  };
}

test("accepts up to six chronologically separate moments under 50 seconds", () => {
  const result = validateAnalysis(validReport());
  assert.equal(result.moments.length, 6);
  assert.ok(result.moments.every((moment) => moment.endSeconds - moment.startSeconds < 50));
});

test("accepts a smaller set of strong moments", () => {
  const report = validReport();
  report.moments = report.moments.slice(0, 3);
  const result = validateAnalysis(report);
  assert.equal(result.moments.length, 3);
});

test("rejects an empty or oversized moment set", () => {
  const emptyReport = validReport();
  emptyReport.moments = [];
  assert.throws(() => validateAnalysis(emptyReport), { code: "invalid_model_output" });
  const oversizedReport = validReport();
  oversizedReport.moments.push({ startSeconds: 190, endSeconds: 200, title: "Moment 7", reason: "An extra source-grounded explanation." });
  assert.throws(() => validateAnalysis(oversizedReport), { code: "invalid_model_output" });
});

test("rejects a moment that does not contain valid boundaries", () => {
  const report = validReport();
  report.moments[0].endSeconds = report.moments[0].startSeconds;
  assert.throws(() => validateAnalysis(report), { code: "invalid_model_output" });
});

test("rejects a moment that lasts 50 seconds or more", () => {
  const report = validReport();
  report.moments[2].endSeconds = report.moments[2].startSeconds + 50;
  assert.throws(() => validateAnalysis(report), { code: "moment_too_long" });
});

test("rejects a moment extending past the source runtime", () => {
  const report = validReport();
  report.moments[5].startSeconds = 190;
  report.moments[5].endSeconds = report.durationSeconds + 1;
  assert.throws(() => validateAnalysis(report), { code: "moment_out_of_range" });
});

test("rejects overlapping moments", () => {
  const report = validReport();
  report.moments[1].startSeconds = report.moments[0].endSeconds - 1;
  assert.throws(() => validateAnalysis(report), { code: "moment_overlap" });
});

test("treats a model-reported unavailable video as an unavailable analysis", () => {
  assert.throws(
    () => validateAnalysis({ videoStatus: "video_unavailable", durationSeconds: 0, moments: [], error: "" }),
    { code: "video_unavailable" },
  );
});
