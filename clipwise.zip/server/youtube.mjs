const VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;
const ALLOWED_HOSTS = new Set(["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be"]);

export class YouTubeLinkError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.name = "YouTubeLinkError";
    this.code = code;
    this.status = status;
  }
}

export function parseYouTubeLink(raw) {
  if (typeof raw !== "string" || raw.length > 2048) {
    throw new YouTubeLinkError("invalid_link", "Paste one public YouTube video link to continue.");
  }

  let url;
  try {
    url = new URL(raw.trim());
  } catch {
    throw new YouTubeLinkError("invalid_link", "That link does not look like a valid YouTube video URL.");
  }

  const host = url.hostname.toLowerCase();
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new YouTubeLinkError("invalid_link", "Use a public YouTube video link that starts with youtube.com or youtu.be.");
  }
  if (url.port) {
    throw new YouTubeLinkError("unsupported_link", "Use a standard YouTube share URL without a custom port.");
  }
  if (url.username || url.password || !ALLOWED_HOSTS.has(host)) {
    throw new YouTubeLinkError("unsupported_link", "Only public YouTube video links are supported. Paste a youtube.com or youtu.be link.");
  }

  const parts = url.pathname.split("/").filter(Boolean);
  let id = "";
  if (host === "youtu.be" || host === "www.youtu.be") {
    id = parts[0] ?? "";
  } else if (url.pathname === "/watch") {
    id = url.searchParams.get("v") ?? "";
  } else if (["shorts", "embed", "live"].includes(parts[0] ?? "")) {
    id = parts[1] ?? "";
  }

  if (!VIDEO_ID.test(id)) {
    throw new YouTubeLinkError("invalid_link", "Paste a single YouTube video URL, not a channel, playlist, or search page.");
  }

  return {
    id,
    canonicalUrl: `https://www.youtube.com/watch?v=${id}`,
  };
}

export async function verifyPublicYouTubeLink(raw) {
  const parsed = parseYouTubeLink(raw);
  const endpoint = new URL("https://www.youtube.com/oembed");
  endpoint.searchParams.set("url", parsed.canonicalUrl);
  endpoint.searchParams.set("format", "json");

  let response;
  try {
    response = await fetch(endpoint, { signal: AbortSignal.timeout(12_000) });
  } catch (error) {
    if (error?.name === "TimeoutError" || error?.name === "AbortError") {
      throw new YouTubeLinkError("youtube_timeout", "YouTube did not respond in time. Try the same link again in a moment.", 503);
    }
    throw new YouTubeLinkError("youtube_unreachable", "Clipwise could not check that link with YouTube right now. Please retry.", 503);
  }

  if (!response.ok) {
    throw new YouTubeLinkError(
      "video_unavailable",
      "YouTube did not make this video available to Clipwise. It may be private, age-restricted, removed, or unavailable for embedding.",
      422,
    );
  }

  let metadata;
  try {
    metadata = await response.json();
  } catch {
    throw new YouTubeLinkError("youtube_invalid_response", "YouTube returned an unreadable link response. Please retry.", 503);
  }

  if (typeof metadata?.title !== "string" || typeof metadata?.author_name !== "string") {
    throw new YouTubeLinkError("video_unavailable", "YouTube did not return public video details for this link.", 422);
  }

  return {
    id: parsed.id,
    title: metadata.title.slice(0, 300),
    authorName: metadata.author_name.slice(0, 200),
    watchUrl: parsed.canonicalUrl,
  };
}
