import path from "node:path";
import { fileURLToPath } from "node:url";
import { createServer } from "node:http";
import express from "express";
import { createServer as createViteServer } from "vite";
import { analyzeYouTubeVideo, VideoAnalysisError } from "./analyzer.mjs";
import { parseYouTubeLink, verifyPublicYouTubeLink, YouTubeLinkError } from "./youtube.mjs";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const production = process.env.NODE_ENV === "production";
const port = Number(process.env.PORT ?? 3000);
const app = express();

app.disable("x-powered-by");
app.use(express.json({ limit: "8kb", type: "application/json" }));

app.get("/api/health", (_req, res) => {
  res.status(200).json({ ok: true, service: "clipwise" });
});

app.post("/api/analyze", async (req, res) => {
  let normalized;
  try {
    normalized = parseYouTubeLink(req.body?.url);
  } catch (error) {
    if (error instanceof YouTubeLinkError) {
      return res.status(error.status).json({ error: { code: error.code, message: error.message } });
    }
    return res.status(400).json({ error: { code: "invalid_link", message: "Paste one public YouTube video link to continue." } });
  }

  const controller = new AbortController();
  res.on("close", () => {
    if (!res.writableEnded) controller.abort();
  });
  res.status(200);
  res.set({
    "Content-Type": "application/x-ndjson; charset=utf-8",
    "Cache-Control": "no-store, no-cache, must-revalidate",
    "X-Accel-Buffering": "no",
  });
  res.flushHeaders();
  const send = (event) => {
    if (!res.destroyed) res.write(`${JSON.stringify(event)}\n`);
  };

  send({ type: "stage", step: 0, label: "Checking the public YouTube link", detail: "Confirming that YouTube exposes this video publicly. No media is downloaded or stored." });

  try {
    const video = await verifyPublicYouTubeLink(normalized.canonicalUrl);
    send({ type: "video", video });
    send({ type: "stage", step: 1, label: "AI is reviewing the video", detail: "The built-in model is examining the video's actual frames and audio. This can take a few minutes; keep this tab open." });

    const analysis = await analyzeYouTubeVideo(video.watchUrl, controller.signal);
    send({ type: "stage", step: 2, label: "Checking the six time ranges", detail: "Verifying that all six moments are distinct, within the video, and shorter than 50 seconds." });
    send({ type: "complete", video: { ...video, durationSeconds: analysis.durationSeconds }, moments: analysis.moments });
  } catch (error) {
    if (controller.signal.aborted) return;
    if (error instanceof YouTubeLinkError) {
      send({ type: "failure", code: error.code, message: error.message });
    } else if (error instanceof VideoAnalysisError) {
      send({ type: "failure", code: error.code, message: error.message });
    } else {
      console.error("Unexpected Clipwise analysis failure:", error?.name ?? "UnknownError");
      send({ type: "failure", code: "analysis_failed", message: "The video review could not be completed. No moments were shown; you can retry the same public YouTube link." });
    }
  } finally {
    if (!res.destroyed) res.end();
  }
});

const httpServer = createServer(app);

if (production) {
  const dist = path.join(projectRoot, "dist");
  app.use(express.static(dist, { index: "index.html", maxAge: "1h" }));
  app.use((req, res, next) => {
    if (req.method === "GET" && !req.path.startsWith("/api/")) {
      return res.sendFile(path.join(dist, "index.html"));
    }
    return next();
  });
} else {
  const vite = await createViteServer({
    configFile: path.join(projectRoot, "vite.config.ts"),
    root: projectRoot,
    appType: "spa",
    server: { middlewareMode: true, hmr: { server: httpServer } },
  });
  app.use(vite.middlewares);
}

httpServer.listen(port, "0.0.0.0", () => {
  console.log(`Clipwise listening on 0.0.0.0:${port}`);
});
