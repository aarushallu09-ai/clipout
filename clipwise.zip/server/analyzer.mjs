const MODEL_ID = "gemini-3.8-flash";
const MAX_TRANSPORT_ATTEMPTS = 3;
const MAX_RANGE_REPAIRS = 1;
const ANALYSIS_TIMEOUT_MS = 300_000;

const momentSchema = {
  type: "object",
  additionalProperties: false,
  required: ["startSeconds", "endSeconds", "title", "reason"],
  properties: {
    startSeconds: { type: "integer", minimum: 0 },
    endSeconds: { type: "integer", minimum: 1 },
    title: { type: "string", minLength: 1, maxLength: 100 },
    reason: { type: "string", minLength: 1, maxLength: 280 },
  },
};

const responseSchema = {
  type: "object",
  additionalProperties: false,
  required: ["videoStatus", "durationSeconds", "moments", "error"],
  properties: {
    videoStatus: { type: "string", enum: ["available", "video_unavailable"] },
    durationSeconds: { type: "integer", minimum: 0 },
    moments: { type: "array", maxItems: 6, items: momentSchema },
    error: { type: "string", maxLength: 280 },
  },
};

export class VideoAnalysisError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "VideoAnalysisError";
    this.code = code;
  }
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function retryDelay(retryAfter, attempt) {
  if (retryAfter) {
    const seconds = Number(retryAfter);
    if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000;
    const date = Date.parse(retryAfter);
    if (Number.isFinite(date)) return Math.max(0, date - Date.now());
  }
  return 1000 * 2 ** attempt;
}

function parseModelObject(content) {
  const text = typeof content === "string"
    ? content
    : Array.isArray(content)
      ? content.map((part) => (typeof part?.text === "string" ? part.text : "")).join("\n")
      : "";
  if (!text) throw new VideoAnalysisError("empty_model_output", "The AI returned no video analysis. No moments were shown; you can retry this link.");

  const unfenced = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const start = unfenced.indexOf("{");
  const end = unfenced.lastIndexOf("}");
  if (start < 0 || end <= start) throw new VideoAnalysisError("invalid_model_output", "The video review did not return a usable result.");
  try {
    return JSON.parse(unfenced.slice(start, end + 1));
  } catch {
    throw new VideoAnalysisError("invalid_model_output", "The video review did not return valid moment data.");
  }
}

export function validateAnalysis(value, expectedDurationSeconds = null) {
  if (value?.videoStatus === "video_unavailable") {
    throw new VideoAnalysisError(
      "video_unavailable",
      "The AI could not inspect this video's audiovisual content. Check that it is public and not age-restricted, then retry the link.",
    );
  }

  const durationSeconds = expectedDurationSeconds ?? value?.durationSeconds;
  const moments = value?.moments;
  if (
    value?.videoStatus !== "available" ||
    !Number.isInteger(durationSeconds) ||
    durationSeconds <= 0 ||
    (expectedDurationSeconds !== null && value.durationSeconds !== expectedDurationSeconds) ||
    !Array.isArray(moments) ||
    moments.length < 1 ||
    moments.length > 6
  ) {
    throw new VideoAnalysisError("invalid_model_output", "The AI review did not produce between one and six valid moments. No timestamps were shown; you can retry this link.");
  }

  const cleaned = [];
  for (const item of moments) {
    if (!item || typeof item !== "object") {
      throw new VideoAnalysisError("invalid_model_output", "A returned moment failed the timestamp checks. No timestamps were shown; you can retry this link.");
    }
    const { startSeconds, endSeconds } = item;
    const title = typeof item.title === "string" ? item.title.trim() : "";
    const reason = typeof item.reason === "string" ? item.reason.trim() : "";
    if (!Number.isInteger(startSeconds) || !Number.isInteger(endSeconds) || startSeconds < 0 || endSeconds <= startSeconds) {
      throw new VideoAnalysisError("invalid_model_output", "A returned moment had invalid whole-second boundaries. No timestamps were shown; you can retry this link.");
    }
    if (endSeconds - startSeconds >= 50) {
      throw new VideoAnalysisError("moment_too_long", "At least one moment was 50 seconds or longer. No timestamps were shown; the AI is correcting the time ranges.");
    }
    if (endSeconds > durationSeconds) {
      throw new VideoAnalysisError("moment_out_of_range", "At least one moment ended past the video's reported duration. No timestamps were shown; the AI is correcting the time ranges.");
    }
    if (!title || title.length > 100 || !reason || reason.length > 280) {
      throw new VideoAnalysisError("invalid_model_output", "A returned moment was missing its title or explanation. No timestamps were shown; you can retry this link.");
    }
    cleaned.push({ startSeconds, endSeconds, title, reason });
  }

  cleaned.sort((a, b) => a.startSeconds - b.startSeconds);
  for (let index = 1; index < cleaned.length; index += 1) {
    if (cleaned[index].startSeconds < cleaned[index - 1].endSeconds) {
      throw new VideoAnalysisError("moment_overlap", "The returned moments overlapped. No timestamps were shown; the AI is correcting the time ranges.");
    }
  }
  return { durationSeconds, moments: cleaned };
}

async function requestModel(apiUrl, apiKey, videoUrl, prompt, signal) {
  for (let attempt = 0; attempt < MAX_TRANSPORT_ATTEMPTS; attempt += 1) {
    let response;
    let payload;
    try {
      response = await fetch(`${apiUrl.replace(/\/$/, "")}/v1/chat/completions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: MODEL_ID,
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                { type: "file_url", file_url: { url: videoUrl, mime_type: "video/mp4" } },
              ],
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: { name: "youtube_video_moments", strict: true, schema: responseSchema },
          },
          max_tokens: 3000,
          temperature: 0.1,
          thinking: { budget_tokens: 1024 },
        }),
        signal: AbortSignal.any([signal, AbortSignal.timeout(ANALYSIS_TIMEOUT_MS)]),
      });
      payload = await response.json().catch(() => null);
    } catch (error) {
      if (signal?.aborted) throw new VideoAnalysisError("cancelled", "The video review was cancelled before it finished.");
      if (error?.name === "TimeoutError") {
        throw new VideoAnalysisError("timeout", "The video review took too long to finish. No moments were returned; you can retry this link.");
      }
      throw new VideoAnalysisError("service_unavailable", "Built-in AI could not complete the video review. You can retry the same link.");
    }

    const retryable = response.status === 429 || response.status >= 500;
    if (retryable && attempt < MAX_TRANSPORT_ATTEMPTS - 1) {
      await wait(retryDelay(response.headers.get("retry-after"), attempt));
      continue;
    }
    if (!response.ok || payload?.error) {
      throw new VideoAnalysisError("service_unavailable", "Built-in AI could not complete the video review. You can retry the same link.");
    }
    return parseModelObject(payload?.choices?.[0]?.message?.content);
  }
  throw new VideoAnalysisError("service_unavailable", "Built-in AI could not complete the video review. You can retry the same link.");
}

function analysisPrompt() {
  return [
    "Carefully inspect the actual public YouTube video provided as video input, using its visual frames and original audio. Review the whole timeline from beginning to end before choosing moments; do not just sample the opening.",
    "Do not infer from the URL, video title, metadata, description, search results, remembered knowledge, or captions. Use only what you actually observe in this video. If you cannot access the audiovisual content, set videoStatus to video_unavailable, durationSeconds to 0, moments to an empty array, and explain briefly in error. Do not guess.",
    "When the video is available, set videoStatus to available, report the exact full-video runtime in integer seconds, and choose up to six distinct, non-overlapping moments worth highlighting. Return as many strong moments as the source supports, from one to six; do not pad the list with weak or invented picks. Rank them for hook strength, clarity, self-contained context, emotional or intellectual payoff, humor, surprise, and editability. Prefer strong entry and exit points, avoid dead air and incomplete setups, and distribute selections across the full timeline where appropriate.",
    "Every moment must use integer second boundaries. It must have a positive duration strictly shorter than 50 seconds, start at or after zero, end at or before the exact runtime, and start at or after the previous moment's end. Sort moments in chronological order. Titles must be 100 characters or less, and reasons must be 280 characters or less and grounded in what is seen or heard.",
    "Return only one JSON object with exactly these fields: videoStatus, durationSeconds, moments, error. For a successful review set error to an empty string and include one to six moments. Do not add markdown, introductions, or other text.",
  ].join("\n\n");
}

function repairPrompt(durationSeconds, previous) {
  return [
    "Re-review the same video directly from its visual frames and original audio. The prior candidate list below failed timestamp validation.",
    `The runtime reported in the first review is ${durationSeconds} seconds. Treat this as the hard source boundary: every startSeconds and endSeconds must be no greater than ${durationSeconds}. Do not create any timestamp after this boundary.`,
    "Return a corrected set of one to six distinct, non-overlapping moments, sorted chronologically. Keep the valid candidates where possible, and replace or shorten only the invalid intervals by finding actual moments inside the video. Do not add weak or invented moments just to reach six. Every interval must use whole seconds and be strictly shorter than 50 seconds. If you cannot inspect the source well enough to correct it, return videoStatus video_unavailable, durationSeconds 0, an empty moments array, and a brief error; do not guess.",
    "This was the prior JSON candidate list, which is not trusted until corrected:",
    JSON.stringify(previous),
    "Return only one JSON object with exactly these fields: videoStatus, durationSeconds, moments, error. For success use videoStatus available, the same exact durationSeconds as the first review, and one to six corrected moments. Set error to an empty string.",
  ].join("\n\n");
}

export async function analyzeYouTubeVideo(videoUrl, signal) {
  const apiUrl = process.env.MANUS_API_URL;
  const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) {
    throw new VideoAnalysisError("service_unavailable", "Built-in AI is temporarily unavailable. You can retry the same public link later.");
  }

  let first;
  try {
    first = await requestModel(apiUrl, apiKey, videoUrl, analysisPrompt(), signal);
    return validateAnalysis(first);
  } catch (error) {
    const repairable = error instanceof VideoAnalysisError && ["moment_too_long", "moment_out_of_range", "moment_overlap"].includes(error.code);
    if (!repairable || MAX_RANGE_REPAIRS === 0 || !Number.isInteger(first?.durationSeconds) || first.durationSeconds <= 0) throw error;
  }

  let repaired;
  try {
    repaired = await requestModel(apiUrl, apiKey, videoUrl, repairPrompt(first.durationSeconds, first), signal);
    return validateAnalysis(repaired, first.durationSeconds);
  } catch (error) {
    if (error instanceof VideoAnalysisError && error.code === "video_unavailable") throw error;
    throw new VideoAnalysisError("invalid_model_output", "The AI could not correct the returned timestamps to fit the video's reported runtime. No moments were shown; you can retry the same link.");
  }
}
