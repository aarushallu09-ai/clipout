# TODO — Clipwise

Current state: the server now sends a canonical public YouTube URL as video input to the built-in AI and streams stage-by-stage status. The app accepts one to six source-grounded highlights, displays no unchecked timestamps, and is being prepared for permanent publication.

- [ ] **Accept only eligible public YouTube links without accounts or media uploads.** People paste a public YouTube video URL with no age restriction; the app requires no login. There are no caption/timed-caption fields and no audio/video file uploads. Reject malformed, private, age-restricted, inaccessible, unsupported, or otherwise unavailable links with a clear explanation.

- [ ] **Show the original video on the web page and its highlights beneath it.** Play the original YouTube video in the page through YouTube's player. Put up to six selected moments directly below the player, with their timings and durations. Selecting a moment shows only that highlighted interval in a separate preview below the original player. Do not download, cut, or rehost clips. The player and highlight-card UI exist.

- [x] **Inspect linked video content honestly and report analysis failures.** The backend passes the public video URL to the built-in video model. The app does not rely on captions, metadata, or guesses to create moments; if the model result fails validation or analysis cannot complete, no moments are displayed and the app explains retrying the same link or replacing it.

- [x] **Show patient, transparent processing status.** Display clear status messaging during public-link verification, AI video review, and time-range validation; do not imply inspection completed before the model returns.

- [ ] **Return up to six valid moments after successful analysis.** Every successful analysis returns one to six selected moments, each with a clip span strictly shorter than 50 seconds; the model is not forced to pad the list with weak picks. Both server and client validate moment shape, integer boundaries, duration, and non-overlap.

- [ ] **Explain, time-link, and export every moment on the source video.** Each highlight shows start and end timestamps, duration, a concise title, and a brief explanation of why it is notable. Each timecode opens the original YouTube video at that starting time. The interface downloads a portable JSON marker with the original source URL and exact time range; it does not copy or rehost YouTube media. Playback remains on the original YouTube video. The UI supports these fields for one to six validated moments.

- [ ] **Keep playback and highlight controls usable on mobile.** The original player and selected highlight preview remain full-width with wrapped captions, touch-sized export controls, single-column highlight cards, and no horizontal overflow at narrow phone widths.

- [x] **Keep the experience link-first and human-operated.** Use only the YouTube link as required user input; do not require an account, captions, timed captions, or an uploaded audio/video file.
