import { useMemo, useState, type FormEvent } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type VideoInfo = {
  id: string;
  title: string;
  authorName: string;
  watchUrl: string;
  durationSeconds?: number;
};

type Moment = {
  startSeconds: number;
  endSeconds: number;
  title: string;
  reason: string;
};

type ApiErrorResponse = { error?: { code?: string; message?: string } };
type AnalysisEvent =
  | { type: "stage"; step: number; label: string; detail: string }
  | { type: "video"; video: VideoInfo }
  | { type: "complete"; video: VideoInfo; moments: Moment[] }
  | { type: "failure"; code: string; message: string };

type ViewState = "idle" | "checking" | "unavailable" | "error" | "ready";

function formatTime(value: number): string {
  const seconds = Math.max(0, Math.floor(value));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = seconds % 60;
  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
  }
  return `${minutes}:${String(remainder).padStart(2, "0")}`;
}

function formatDuration(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

function validateMoments(value: unknown, durationSeconds: unknown): value is Moment[] {
  if (typeof durationSeconds !== "number" || !Number.isInteger(durationSeconds) || durationSeconds <= 0) return false;
  if (!Array.isArray(value) || value.length < 1 || value.length > 6) return false;
  const wellFormed = value.every((item) => {
    if (typeof item !== "object" || item === null) return false;
    const moment = item as Partial<Moment>;
    return (
      typeof moment.startSeconds === "number" &&
      Number.isInteger(moment.startSeconds) &&
      moment.startSeconds >= 0 &&
      typeof moment.endSeconds === "number" &&
      Number.isInteger(moment.endSeconds) &&
      moment.endSeconds > moment.startSeconds &&
      moment.endSeconds - moment.startSeconds < 50 &&
      moment.endSeconds <= durationSeconds &&
      typeof moment.title === "string" &&
      moment.title.trim().length > 0 &&
      typeof moment.reason === "string" &&
      moment.reason.trim().length > 0
    );
  });
  if (!wellFormed) return false;
  const ordered = [...(value as Moment[])].sort((a, b) => a.startSeconds - b.startSeconds);
  return ordered.every((moment, index) => index === 0 || moment.startSeconds >= ordered[index - 1].endSeconds);
}

function embedUrl(video: VideoInfo, moment: Moment | null): string {
  const params = new URLSearchParams({ rel: "0", playsinline: "1" });
  if (moment) {
    params.set("start", String(Math.floor(moment.startSeconds)));
    params.set("end", String(Math.ceil(moment.endSeconds)));
  }
  return `https://www.youtube-nocookie.com/embed/${video.id}?${params.toString()}`;
}

function timeLink(video: VideoInfo, startSeconds: number): string {
  const url = new URL(video.watchUrl);
  url.searchParams.set("t", `${Math.floor(startSeconds)}s`);
  return url.toString();
}

function slugify(value: string): string {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || "highlight";
}

function exportMoment(video: VideoInfo, moment: Moment, index: number): void {
  const payload = {
    format: "clipwise-highlight",
    version: 1,
    title: moment.title,
    reason: moment.reason,
    startSeconds: moment.startSeconds,
    endSeconds: moment.endSeconds,
    durationSeconds: moment.endSeconds - moment.startSeconds,
    source: {
      title: video.title,
      authorName: video.authorName,
      videoId: video.id,
      watchUrl: video.watchUrl,
      timestampUrl: timeLink(video, moment.startSeconds),
    },
    note: "This file is a portable timecoded marker for the original YouTube source. Clipwise does not download or rehost video media.",
  };
  const blobUrl = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
  const anchor = document.createElement("a");
  anchor.href = blobUrl;
  anchor.download = `clipwise-highlight-${String(index + 1).padStart(2, "0")}-${slugify(moment.title)}.json`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
}

function MarkIcon({ small = false }: { small?: boolean }) {
  return (
    <span className={`mark-icon${small ? " mark-icon-small" : ""}`} aria-hidden="true">
      <i />
      <i />
      <i />
      <i />
    </span>
  );
}

function App() {
  const [input, setInput] = useState("");
  const [view, setView] = useState<ViewState>("idle");
  const [video, setVideo] = useState<VideoInfo | null>(null);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [activeMoment, setActiveMoment] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const [checkingStep, setCheckingStep] = useState(0);
  const [checkingLabel, setCheckingLabel] = useState("Checking the public YouTube link");
  const [checkingDetail, setCheckingDetail] = useState("Confirming public availability before starting AI review.");

  const selectedMoment = useMemo(
    () => (activeMoment === null ? null : moments[activeMoment] ?? null),
    [activeMoment, moments],
  );

  async function analyzeLink(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    setVideo(null);
    setMoments([]);
    setActiveMoment(null);
    setMessage("");
    setView("checking");
    setCheckingStep(0);
    setCheckingLabel("Checking the public YouTube link");
    setCheckingDetail("Confirming public availability before starting AI review.");
    let videoVerified = false;

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: input.trim() }),
      });

      if (!response.ok) {
        const payload = (await response.json().catch(() => ({}))) as ApiErrorResponse;
        setMessage(payload.error?.message ?? "Clipwise could not check this link. Please try again.");
        setView("error");
        return;
      }

      if (!response.body) throw new Error("Missing streamed analysis response");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let receivedTerminalEvent = false;

      const handleLine = (line: string) => {
        if (!line.trim()) return;
        const event = JSON.parse(line) as AnalysisEvent;
        if (event.type === "stage") {
          setCheckingStep(event.step);
          setCheckingLabel(event.label);
          setCheckingDetail(event.detail);
          return;
        }
        if (event.type === "video") {
          videoVerified = true;
          setVideo(event.video);
          return;
        }
        if (event.type === "complete") {
          receivedTerminalEvent = true;
          videoVerified = true;
          setVideo(event.video);
          if (validateMoments(event.moments, event.video.durationSeconds)) {
            setMoments([...event.moments].sort((a, b) => a.startSeconds - b.startSeconds));
            setView("ready");
            setMessage("");
          } else {
            setView("unavailable");
            setMessage("The AI response did not pass the highlight timestamp checks. No highlights were shown; retry this link.");
          }
          return;
        }
        if (event.type === "failure") {
          receivedTerminalEvent = true;
          setMessage(event.message);
          setView(videoVerified ? "unavailable" : "error");
        }
      };

      while (true) {
        const { value, done } = await reader.read();
        buffer += decoder.decode(value ?? new Uint8Array(), { stream: !done });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) handleLine(line);
        if (done) break;
      }
      if (buffer.trim()) handleLine(buffer);
      if (!receivedTerminalEvent) throw new Error("Analysis stream ended without a final result");
    } catch {
      setMessage(videoVerified ? "The analysis connection ended before a verified result arrived. No moments were shown; retry the same link." : "Clipwise could not finish checking this link. Check your connection and try again.");
      setView(videoVerified ? "unavailable" : "error");
    }
  }

  function resetToRetry() {
    setVideo(null);
    setMoments([]);
    setActiveMoment(null);
    setMessage("");
    setView("idle");
  }

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" aria-hidden="true" />
      <div className="ambient ambient-two" aria-hidden="true" />

      <header className="topbar">
        <a className="wordmark" href="#top" aria-label="Clipwise home">
          <MarkIcon />
          <span>CLIPWISE</span>
        </a>
        <div className="topbar-right">
          <span className="topbar-label">YOUTUBE MOMENT FINDER</span>
          <span className="privacy-pill"><span className="live-dot" /> NO LOGIN · LINK ONLY</span>
        </div>
      </header>

      <main id="top">
        <section className="hero" aria-labelledby="hero-heading">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> PUBLIC VIDEO · ORIGINAL SOURCE</div>
            <h1 id="hero-heading">Find the moment.<br /><em>Stay in the original.</em></h1>
            <p className="hero-intro">
              Paste one public YouTube link and give the built-in AI time to review the full video. Get up to six strong moments under 50 seconds each, then jump straight to them in the original player.
            </p>
            <div className="promise-row" aria-label="Clipwise requirements">
              <span><b>01—06</b> moments</span>
              <span><b>&lt;50s</b> each</span>
              <span><b>YT</b> source only</span>
            </div>
          </div>

          <aside className="signal-card" aria-label="How Clipwise works">
            <div className="signal-card-head"><span>ANALYSIS PATH</span><span>01 — 03</span></div>
            <div className="signal-steps">
              <div className="signal-step"><span className="step-number">01</span><span>Check public link</span><span className="step-state">READY</span></div>
              <div className="signal-step"><span className="step-number">02</span><span>Review full video</span><span className="step-state">BUILT-IN AI</span></div>
              <div className="signal-step"><span className="step-number">03</span><span>Return up to six timecodes</span><span className="step-state">&lt;50 SEC EACH</span></div>
            </div>
            <div className="signal-trace" aria-hidden="true"><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /></div>
            <div className="signal-caption"><span className="signal-caption-dot" /> No captions or file uploads required</div>
          </aside>
        </section>

        <section className="workbench" aria-label="Analyze a YouTube link">
          <div className="workbench-topline"><span>01 / ADD A SOURCE</span><span>PUBLIC YOUTUBE VIDEO ONLY</span></div>
          <form className="link-form" onSubmit={analyzeLink}>
            <label className="sr-only" htmlFor="youtube-url">YouTube video link</label>
            <div className="input-wrap">
              <span className="link-icon" aria-hidden="true">↗</span>
              <input
                id="youtube-url"
                type="url"
                value={input}
                onChange={(event) => setInput(event.target.value)}
                placeholder="Paste a YouTube link…"
                autoComplete="url"
                required
                aria-describedby="link-hint"
                disabled={view === "checking"}
              />
              {input && <button className="clear-button" type="button" onClick={() => setInput("")} aria-label="Clear link">×</button>}
            </div>
            <button className="analyze-button" type="submit" disabled={view === "checking" || !input.trim()}>
              {view === "checking" ? <><span className="button-spinner" /> Reviewing video</> : <>Analyze video <span aria-hidden="true">↗</span></>}
            </button>
          </form>
          <div id="link-hint" className="form-footnote">
            <span>youtube.com or youtu.be</span>
            <span className="footnote-divider" />
            <span>No sign-in</span>
            <span className="footnote-divider" />
            <span>No captions or uploads</span>
          </div>

          {!video && (
            <div className="capability-note" role="note">
              <span>BUILT-IN AI · PUBLIC LINK ONLY</span>
              <p>The AI reviews the video's actual frames and audio directly from its public YouTube link. Longer videos can take a few minutes. No captions, timed captions, or media uploads are needed.</p>
            </div>
          )}

          {view === "checking" && (
            <div className="status-panel checking-panel" role="status" aria-live="polite">
              <span className="status-orbit"><span /></span>
              <div>
                <strong>{checkingLabel}</strong>
                <p>{checkingDetail}</p>
              </div>
              <span className="status-code">STEP 0{checkingStep + 1}</span>
            </div>
          )}

          {view === "error" && (
            <div className="status-panel error-panel" role="alert">
              <span className="status-symbol">!</span>
              <div className="status-copy"><strong>Link not available</strong><p>{message}</p></div>
              <button className="text-button" type="button" onClick={resetToRetry}>Try another link <span aria-hidden="true">↗</span></button>
            </div>
          )}
        </section>

        {video && (
          <section className="source-section" aria-label="Original video and moment highlights">
            <div className="source-heading">
              <div>
                <div className="eyebrow"><span className="eyebrow-line" /> ORIGINAL YOUTUBE SOURCE</div>
                <h2>{video.title}</h2>
                <p className="source-author">{video.authorName}</p>
              </div>
              <a className="source-link" href={video.watchUrl} target="_blank" rel="noreferrer">Open on YouTube <span aria-hidden="true">↗</span></a>
            </div>

            {view === "unavailable" && (
              <div className="analysis-notice" role="status">
                <div className="notice-icon"><MarkIcon small /></div>
                <div className="notice-body">
                  <div className="notice-kicker">NO UNVERIFIED TIMESTAMPS</div>
                  <h3>This analysis did not produce any valid moments</h3>
                  <p>{message}</p>
                  <div className="notice-actions">
                    <button className="text-button" type="button" onClick={() => void analyzeLink()}>Retry this link <span aria-hidden="true">↻</span></button>
                    <button className="text-button subdued-button" type="button" onClick={resetToRetry}>Replace link <span aria-hidden="true">↗</span></button>
                  </div>
                </div>
                <span className="notice-stamp">NO<br />GUESSING</span>
              </div>
            )}

            <div className="player-frame original-player-frame">
              <iframe
                src={embedUrl(video, null)}
                title={`Original YouTube video: ${video.title}`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              />
            </div>
            <div className="player-caption">
              <span><span className="live-dot" /> PLAYING THE ORIGINAL YOUTUBE VIDEO</span>
              <span>NO VIDEO COPIES OR DOWNLOADS</span>
            </div>

            {selectedMoment && (
              <div className="highlight-preview" aria-label={`Highlighted moment preview: ${selectedMoment.title}`}>
                <div className="highlight-preview-heading">
                  <div>
                    <div className="eyebrow"><span className="eyebrow-line" /> SELECTED HIGHLIGHT · ORIGINAL SOURCE</div>
                    <h3>{selectedMoment.title}</h3>
                  </div>
                  <span className="highlight-preview-time">{formatTime(selectedMoment.startSeconds)} → {formatTime(selectedMoment.endSeconds)}</span>
                </div>
                <div className="player-frame highlight-player-frame">
                  <iframe
                    key={`${video.id}-${selectedMoment.startSeconds}-${selectedMoment.endSeconds}`}
                    src={embedUrl(video, selectedMoment)}
                    title={`Highlighted moment: ${selectedMoment.title}`}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                  />
                </div>
                <div className="player-caption highlight-preview-caption">
                  <span><span className="live-dot" /> HIGHLIGHT PREVIEW · {formatDuration(selectedMoment.endSeconds - selectedMoment.startSeconds)} SEC</span>
                  <span className="highlight-caption-actions"><span>ORIGINAL YOUTUBE PLAYER</span><button className="export-button" type="button" onClick={() => exportMoment(video, selectedMoment, activeMoment ?? 0)}>Download marker</button></span>
                </div>
              </div>
            )}

            <div className="moment-section">
              <div className="moment-heading">
                <div><div className="eyebrow"><span className="eyebrow-line" /> HIGHLIGHT MARKERS</div><h3>Moments in this video</h3></div>
                <span className="moment-count">{moments.length.toString().padStart(2, "0")} / 06 MAX</span>
              </div>
              {moments.length > 0 && moments.length <= 6 ? (
                <div className="moment-list">
                  {moments.map((moment, index) => {
                    const duration = moment.endSeconds - moment.startSeconds;
                    const active = activeMoment === index;
                    return (
                      <article className={`moment-card${active ? " active-moment" : ""}`} key={`${moment.startSeconds}-${index}`}>
                        <button className="moment-select" type="button" onClick={() => setActiveMoment(index)} aria-pressed={active}>
                          <span className="moment-index">{String(index + 1).padStart(2, "0")}</span>
                          <span className="moment-main"><strong>{moment.title}</strong><span className="moment-time">{formatTime(moment.startSeconds)} <i>→</i> {formatTime(moment.endSeconds)} <b>{formatDuration(duration)} SEC</b></span></span>
                          <span className="moment-play" aria-hidden="true">{active ? "✓" : "▶"}</span>
                        </button>
                        <p>{moment.reason}</p>
                        <div className="moment-actions">
                          <a className="moment-youtube-link" href={timeLink(video, moment.startSeconds)} target="_blank" rel="noreferrer">Open this time on YouTube <span aria-hidden="true">↗</span></a>
                          <button className="export-button" type="button" onClick={() => exportMoment(video, moment, index)}>Download marker</button>
                        </div>
                      </article>
                    );
                  })}
                </div>
              ) : (
                <div className="empty-moments">
                  <div className="empty-track" aria-hidden="true"><span /><span /><span /><span /><span /><span /></div>
                  <div className="empty-copy"><strong>{view === "checking" ? "The AI is reviewing the video before choosing highlights." : "No timestamps are shown unless at least one passes the checks."}</strong><span>{view === "checking" ? "This can take a few minutes. The player below remains the original YouTube source." : "Retry the public link if the AI review was interrupted or unavailable."}</span></div>
                  <span className="empty-state">{view === "checking" ? "AI REVIEW<br />IN PROGRESS" : "NO UNVERIFIED<br />MOMENTS"}</span>
                </div>
              )}
              <p className="moment-footnote">Selecting a marker opens its clip-only preview below the original player. Download marker exports the source URL and exact time range; no video copy is created.</p>
            </div>
          </section>
        )}

        <section className="principles" aria-label="Clipwise principles">
          <div className="principle"><span>01</span><div><strong>Link in</strong><p>One public YouTube URL. That's all.</p></div></div>
          <div className="principle"><span>02</span><div><strong>Source stays put</strong><p>Original video plays on YouTube.</p></div></div>
          <div className="principle"><span>03</span><div><strong>No invented picks</strong><p>If the video can't be read, we say so.</p></div></div>
        </section>
      </main>

      <footer className="footer"><a className="wordmark footer-wordmark" href="#top"><MarkIcon small /><span>CLIPWISE</span></a><span>PUBLIC LINKS · ORIGINAL VIDEO · HONEST RESULTS</span><span>© {new Date().getFullYear()} CLIPWISE</span></footer>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
